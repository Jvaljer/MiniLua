print("hello", 42, true)
