x = 0
x = (x + 1) * 2

print(x, 2 * x)
