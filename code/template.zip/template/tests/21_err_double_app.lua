print(42)("abc")
