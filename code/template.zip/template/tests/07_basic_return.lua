x = 42
return x
-- having code after the return is forbidden by the parser!
