function f(a, a) print(a) end
f(1, 2)
f(1)
f(1, 2, 3)