print(x)
x = "abc"
print(x)
