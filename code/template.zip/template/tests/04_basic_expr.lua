print(1 + 2)
print(44 - 2)
print(2 * 2 + 1)
print(- 3)

print(x == nil)
print(y == x)
print(x == 3)

print(3 ~= 12)
print("abc" ~= "def")
